import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;


import java.time.LocalDate;
import org.junit.Before;
import org.junit.Test;

public class CovidLocationStatsTest {

  @Before
  public void setUp() throws Exception {
  }

  /**
   * Tests the construction of an instance, using valid parameters.
   * Checks that all fields of the object is being correctly
   * initialized.
   *
   * This is a positive test, since it determines that the object works as
   * expected.
   */
  @Test
  public void testConstructorWithValidInput() {
    CovidLocationStats covidLocationStats =
        new CovidLocationStats(LocalDate.of(2020,3,28)
        , "CHINA", 23, 34);

    assertEquals("CHINA", covidLocationStats.getCountry());
    assertEquals(23, covidLocationStats.getNumberOfInfected());
    assertEquals(34, covidLocationStats.getNumberOfDeaths());
    assertTrue(LocalDate.of(2020, 3, 28)
        .isEqual(covidLocationStats.getDate()));
  }

  /**
   * Tests the construction of an instance, using invalid values for the
   * country parameter.
   * Checks that the class is capable of handling invalid data in a proper way,
   * by setting the country name to the string "IVALID COUNTRY"
   *
   * This is a negative test, since the test ensures that the
   * object can gracefully handle invalid input or unexpected use of the object.
   */
  @Test
  public void testConstructorWithInvalidCountryInput() {

      CovidLocationStats covidLocationStats =
          new CovidLocationStats(LocalDate.of(2020, 3, 28)
              , null, 23, 34);
      assertEquals("IVALID COUNTRY", covidLocationStats.getCountry());
  }
}