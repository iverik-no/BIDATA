
import javax.swing.JOptionPane;

/**
 * Represents the user interface for the application. This version makes use of
 * JOptionPane for the interaction with the user.
 *
 * @author Grethe Sandstrak
 */
public class CovidStatsUI2 {

    private static final String VERSION = "v1.0-SNAPSHOT";

    private CovidStatsRegister covidStatsRegister;

    String[] menuItems
            = {
                "1. Add a COVID-19 entry\n",
                "2. List all COVID-19 entries in the register\n",
                "3. Find COVID-19 entry by date",
                "4. Find all entries after date",
                "5. Show the total deaths for a country",
                "6. EXIT"
            };

    // Constants defining the different menu options, to be used in the
    // switch-case.
    private static final int ADD_COVID_ENTRY_TO_REGISTER = 1;
    private static final int LIST_ALL_COVID_ENTRIES = 2;
    private static final int FIND_COVID_ENTRY_BY_DATE = 3;
    private static final int FIND_COVID_ENTRY_AFTER_DATE = 4;
    private static final int CALCULATE_TOTAL_DEATHS = 5;
    private static final int EXIT = 6;

    /**
     * Creates an instance of the CovidStatsUI2 User interface. An instance of
     * the CovidStatsRegister is created.
     */
    public CovidStatsUI2() {
        this.covidStatsRegister = new CovidStatsRegister();
    }

    /**
     * Starts the application by showing the menu and retrieving input from the
     * user. Continues until the user decides to exit the application.
     */
    void start() {

        boolean quit = false;

        while (!quit) {
            int menuSelection = this.getMenuChoice();
            System.out.println("menuSelection: " + menuSelection);
            switch (menuSelection) {
                case ADD_COVID_ENTRY_TO_REGISTER:
                    //this.addCovidStatsToRegister();
                    break;

                case LIST_ALL_COVID_ENTRIES:
                    //this.listAllCovidEntries();
                    break;

                case FIND_COVID_ENTRY_BY_DATE:
                    //this.findCovidEntryByDate();
                    break;

                case FIND_COVID_ENTRY_AFTER_DATE:
                    //this.findCovidStatsAfterDate();
                    break;

                case CALCULATE_TOTAL_DEATHS:
                    //this.calculateDeathsByCountry();
                    break;

                case EXIT:
                    System.out.println("\nThank you for using the COVID-19 stats Application "
                            + VERSION + ". Bye!\n");
                    quit = true;
                    break;

                default:
                    System.out.println(
                            "\nERROR: Please provide a number between 1 and " + this.menuItems.length + "..\n");
            }
        }

    }

    /**
     * Displays the menu to the user, and waits for the users input. The user is
     * expected to input an integer between 1 and the max number of menu items..
     * The method returns the input from the user. If the input from the user is
     * invalid, 0 is returned.
     *
     * @return the menu number (between 1 and max menu item number) provided by
     * the user.
     */
    private int getMenuChoice() {
        int menuSelection = 0;
        int maxMenuItemNumber = menuItems.length;

        //TODO: Grethe fyller ut!!
        return menuSelection + 1;
    }

}
