import java.time.LocalDate;

/**
 * Represents a single registration of Covid-19 statistics.
 * The statistics registered are number of infected, and
 * number of deaths at a specific date in a specific country.
 */
public class CovidLocationStats {
  private LocalDate date;
  private String country;
  private int numberOfInfected;
  private int numberOfDeaths;

  /**
   * Creates an instance of a Covid-19 registration.
   *
   * @param date date of registration
   * @param country country of statistics
   * @param numberOfInfected number of infected people at the given date
   * @param numberOfDeaths number of deaths at the given date
   */
  public CovidLocationStats(LocalDate date, String country, int numberOfInfected,
                            int numberOfDeaths) {
    this.setDate(date);
    this.setCountry(country);
    this.setNumberOfInfected(numberOfInfected);
    this.numberOfDeaths = numberOfDeaths;
  }

  /**
   * Returns the date of registration.
   * @return the date of registration
   */
  public LocalDate getDate() {
    return date;
  }


  /**
   * Returns the country of the registration.
   * @return the country of the registration
   */
  public String getCountry() {
    return country;
  }

  /**
   * Returns the number of infected.
   * 
   * @return the number of infected
   */
  public int getNumberOfInfected() {
    return numberOfInfected;
  }

  /**
   * Returns the number of deaths.
   * 
   * @return the number of deaths
   */
  public int getNumberOfDeaths() {
    return numberOfDeaths;
  }

  /**
   * Set the number of deaths.
   * 
   * @param numberOfDeaths the number of deaths
   */
  private void setNumberOfDeaths(int numberOfDeaths) {
    // Do not allow negative numbers. 0 is valid
    if (numberOfDeaths < 0) {
      this.numberOfDeaths = 0;
    } else {
      this.numberOfDeaths = numberOfDeaths;
    }
  }
  
  /**
   * Set number of infected. If the number of infected provided
   * is negative, the number is set to 0.
   * 
   * @param numberOfInfected the number of infected people
   */
  private void setNumberOfInfected(int numberOfInfected) {
    // Do not allow negative numbers. 0 is valid
    if (numberOfInfected < 0) {
      this.numberOfInfected = 0;
    } else {
      this.numberOfInfected = numberOfInfected;
    }
  } 
  
  /**
   * Set the country of registration.
   * 
   * @param country the country of registration
   */
  private void setCountry(String country) {
    // Do not allow null or empty strings
    if ((country == null)  || (country.trim().isEmpty())) {
      this.country = "IVALID COUNTRY";
    } else {
      this.country = country;
    }
  }

  /**
   * Set the date of registration.
   * 
   * @param date the date of registration
   */
  private void setDate(LocalDate date) {
    this.date = date;
  }  
}
