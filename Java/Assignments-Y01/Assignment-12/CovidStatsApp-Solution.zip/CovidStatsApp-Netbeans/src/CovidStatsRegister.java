
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Holds all Covid-19 statistics having been registered. The register provides
 * functionality for adding new Covid statistics, and to perform different types
 * of searches in the register.
 */
public class CovidStatsRegister {
    // Chose to use an ArrayList. Could also have have used a HashSet since
    // Indexing is not really helpfull in this case.
    // HashMap is not very suitable, since a single COVID-registration
    // has no unique identifier that could have been used for a key.

    private ArrayList<CovidLocationStats> covidStats;

    /**
     * Creates an instance of the register.
     */
    public CovidStatsRegister() {
        this.covidStats = new ArrayList<>();
    }

    /**
     * Adds a Covid stats instance to the register.
     *
     * @param covidLocationStats the Covid stats to add
     */
    public void addCovidStats(CovidLocationStats covidLocationStats) {
        // Do not allow to add stats if null
        if (null != covidLocationStats) {
            this.covidStats.add(covidLocationStats);
        }
    }

    /**
     * Returns the first Covid statistics registered on a given date. If not
     * statistics is found, <code>null</code> is returned.
     *
     * @param date the date to search for.
     * @return the first Covid statistics registered on a given date
     */
    public CovidLocationStats findCovidStatsByDate(LocalDate date) {
        CovidLocationStats foundCovidLocStats = null;
        Iterator<CovidLocationStats> it = this.covidStats.iterator();

        while (it.hasNext() && (foundCovidLocStats == null)) {
            CovidLocationStats covidLocStats = it.next();
            if (covidLocStats.getDate().isEqual(date)) {
                foundCovidLocStats = covidLocStats;
            }
        }
        return foundCovidLocStats;
    }

    /**
     * Returns a collection of Covid-statistics registered after the date
     * provided. If no stats found, an empty collection is returned.
     *
     * @param date the start date for the search
     * @return a collection of Covid-statistics registered after the date
     * provided.
     */
    public ArrayList<CovidLocationStats> findCovidStatsAfterDate(LocalDate date) {
        ArrayList<CovidLocationStats> foundCovidStats = new ArrayList<>();
        for (CovidLocationStats covidLocationStats : this.covidStats) {
            if (covidLocationStats.getDate().isAfter(date)) {
                foundCovidStats.add(covidLocationStats);
            }
        }
        return foundCovidStats;
    }

    /**
     * Returns the number of deaths for a specific country. If the country was
     * not found, -1 is returned.
     *
     * @param country the country to return stats for
     * @return the number of deaths for a specific country. If the country was
     * not found, -1 is returned.
     */
    public int getNumberOfDeathsInCountry(String country) {
        int result = -1;
        // Guard conditions. Hence multiple return-statements are OK.
        if (country == null) {
            return -1;
        }
        if (country.isEmpty()) {
            return -1;
        }
        // From here and onwards, the parameter country is valid.
        for (CovidLocationStats covidLocationStats : this.covidStats) {
            if (covidLocationStats.getCountry().equalsIgnoreCase(country)) {
                result += covidLocationStats.getNumberOfDeaths();
            }
        }
        return result;
    }

    /**
     * Returns the total number of deaths.
     *
     * @return the total number of deaths.
     */
    public int getTotalNumberOfDeaths() {
        int result = 0;
        for (CovidLocationStats covidLocationStats : this.covidStats) {
            result += covidLocationStats.getNumberOfDeaths();
        }
        return result;
    }

    /**
     * Returns the total number of infected.
     *
     * @return the total number of infected.
     */
    public int getTotalNumberOfInfected() {
        int result = 0;
        for (CovidLocationStats covidLocationStats : this.covidStats) {
            result += covidLocationStats.getNumberOfInfected();
        }
        return result;
    }

    /**
     * Returns the iterator to the register of Covid stats.
     *
     * @return the iterator to the register of Covid stats.
     */
    public Iterator<CovidLocationStats> getIterator() {
        return this.covidStats.iterator();
    }

    /**
     * Returns the number of entries in the register.
     *
     * @return the number of entries in the register.
     */
    public int getNumberOfEntries() {
        return this.covidStats.size();
    }
}
