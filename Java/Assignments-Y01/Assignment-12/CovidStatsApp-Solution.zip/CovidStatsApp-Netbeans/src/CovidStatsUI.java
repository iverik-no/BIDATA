
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

/**
 * Makes up the user interface (text based) of the application. Responsible for
 * the part of user interaction related to the menu, like displaying the menu,
 * and getting the choice from the user.
 *
 * @author asty
 * @version 1.0
 */
class CovidStatsUI {
  private static final String VERSION = "v1.0-SNAPSHOT";

  private CovidStatsRegister covidStatsRegister;

  // Constants used to format the output as a table
  private static final String FORMAT_TITLE = "|%1$-12s|%2$-10s|%3$-10s|%4$-10s|\n";
  private static final String FORMAT_ROW = "|%1$-12s|%2$-10s|%3$10d|%4$10d|\n";
  private static final String TABLE_TITLE = String.format(FORMAT_TITLE
      , "Date", "Country", "Infected", "Dead");
  private static final String TABLE_DIVIDER = "===============================================";


  String[] menuItems =
      {
          "1. Add a COVID-19 entry",
          "2. List all COVID-19 entries in the register",
          "3. Find COVID-19 entry by date",
          "4. Find all entries after date",
          "5. Show the total deaths for a country"
      };

  // Constants defining the different menu options, to be used in the
  // switch-case.
  private static final int ADD_COVID_ENTRY_TO_REGISTER = 1;
  private static final int LIST_ALL_COVID_ENTRIES = 2;
  private static final int FIND_COVID_ENTRY_BY_DATE = 3;
  private static final int FIND_COVID_ENTRY_AFTER_DATE = 4;
  private static final int CALCULATE_TOTAL_DEATHS = 5;
  private static final int EXIT = 6;

  /**
   * Creates an instance of the CovidStatsUI User interface.
   * An instance of the CovidStatsRegister is created.
   */
  public CovidStatsUI() {
    this.covidStatsRegister = new CovidStatsRegister();
  }

  /**
   * Starts the application by showing the menu and retrieving input from the
   * user.
   * Continues until the user decides to exit the application.
   */
  void start() {
    init();

    boolean quit = false;

    while (!quit) {
      int menuSelection = this.getMenuChoice();
      switch (menuSelection) {
        case ADD_COVID_ENTRY_TO_REGISTER:
          this.addCovidStatsToRegister();
          break;

        case LIST_ALL_COVID_ENTRIES:
          this.listAllCovidEntries();
          break;

        case FIND_COVID_ENTRY_BY_DATE:
          this.findCovidEntryByDate();
          break;

        case FIND_COVID_ENTRY_AFTER_DATE:
          this.findCovidStatsAfterDate();
          break;

        case CALCULATE_TOTAL_DEATHS:
          this.calculateDeathsByCountry();
          break;

        case EXIT:
          System.out.println("\nThank you for using the COVID-19 stats Application "
              + VERSION + ". Bye!\n");
          quit = true;
          break;

        default:
          System.out.println(
              "\nERROR: Please provide a number between 1 and " + this.menuItems.length + "..\n");
      }
    }

  }

  /**
   * Displays the menu to the user, and waits for the users input. The user is
   * expected to input an integer between 1 and the max number of menu items..
   * The method returns the input from the user. If the input from the user
   * is invalid, 0 is returned.
   *
   * @return the menu number (between 1 and max menu item number) provided by
   * the user.
   */
  private int getMenuChoice() {
    int menuSelection = 0;

    System.out.println("\n**** COVID-19 Stats Tool " + VERSION + " ****\n");
    for (String menuItem : menuItems) {
      System.out.println(menuItem);
    }
    int maxMenuItemNumber = menuItems.length + 1;
    System.out.println(maxMenuItemNumber + ". Exit\n");
    System.out.println("Please choose menu item (1-" + maxMenuItemNumber + "): ");

    Scanner reader = new Scanner(System.in);
    if (reader.hasNextInt()) {
      menuSelection = reader.nextInt();
    } else {
      System.out.println("You must enter a number, not text");
    }
    return menuSelection;
  }

  /**
   * A helper method that fills the register(s) with some data for testing
   * purposes.
   */
  private void fillRegistersWithDataForTesting() {
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 1, 19)
            , "CHINA", 136, 1));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 2, 5)
            , "CHINA", 3872, 66));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 3, 7)
            , "NORGE", 3, 0));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 3, 9)
            , "USA", 259, 4));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 3, 9)
            , "CHINA", 45, 23));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 3, 22)
            , "NORGE", 240, 8));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 3, 24)
            , "USA", 20341, 119));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 3, 25)
            , "CHINA", 28, 4));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 4, 6)
            , "NORGE", 110, 3));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 4, 10)
            , "USA", 30859, 2087));
    this.covidStatsRegister.addCovidStats(
        new CovidLocationStats(LocalDate.of(2020, 4, 10)
            , "CHINA", 55, 1));

  }

  /**
   * Initialises the application.
   */
  public void init() {
    this.fillRegistersWithDataForTesting();
  }


  /**
   * Asks the user to provide the necessary data for a covid statistics to
   * be registered.
   * If the data provided is valid, the stats is added to the register.
   */
  public void addCovidStatsToRegister() {
    boolean validInput = true;

    // The data to be collected, with some initial default values:
    LocalDate date = null;
    String country = null;
    int numberOfInfected = 0;
    int numberOfDeaths = 0;

    System.out.println("Please enter statistics to be registered:\n");
    Scanner reader = new Scanner(System.in);

    System.out.println("Please enter date (YYYY-MM-DD): ");
    String dateString = reader.nextLine();

    date = LocalDate.parse(dateString);

    System.out.println("Please enter country: ");
    country = reader.nextLine();
    if (country.isEmpty()) {
      validInput = false;
    }

    if (validInput) {
      System.out.println("Please enter number of infected: ");
      numberOfInfected = reader.nextInt();
      if (numberOfInfected < 0) {
        validInput = false;
      }
    }

    if (validInput) {
      System.out.println("Please enter number of deaths: ");
      numberOfDeaths = reader.nextInt();
      if (numberOfDeaths < 0) {
        validInput = false;
      }
    }

    if (validInput) {
      this.covidStatsRegister.addCovidStats(
          new CovidLocationStats(date, country, numberOfInfected, numberOfDeaths));
      System.out.println("\nCovid-19 statistics registered successfully.\n");
    } else {
      System.out
          .println("\nSome of the data entered was invalid. No Covid statistics have been added.");
    }
  }


  /**
   * List all the Covid statistics in the register.
   */
  public void listAllCovidEntries() {
    System.out.print(TABLE_TITLE);
    System.out.println(TABLE_DIVIDER);

    Iterator<CovidLocationStats> it = this.covidStatsRegister.getIterator();

    while (it.hasNext()) {
      CovidLocationStats covidStat = it.next();
      System.out.format(FORMAT_ROW
          , covidStat.getDate().toString()
          , covidStat.getCountry()
          , covidStat.getNumberOfInfected()
          , covidStat.getNumberOfDeaths());
    }
    System.out.println(TABLE_DIVIDER);
    System.out.format(FORMAT_ROW
        , "TOTAL", ""
        , this.covidStatsRegister.getTotalNumberOfInfected()
        , this.covidStatsRegister.getTotalNumberOfDeaths());
  }

  /**
   * Find fist covid entry registered on the date provided by the user.
   */
  public void findCovidEntryByDate() {
    Scanner reader = new Scanner(System.in);

    System.out.println("Please enter the date to search for (YYYY-MM-DD): ");
    String dateString = reader.nextLine();

    LocalDate date = LocalDate.parse(dateString);

    CovidLocationStats covidLocStats = this.covidStatsRegister.findCovidStatsByDate(date);
    if (null == covidLocStats) {
      System.out.println("No Covid-19 statistics was found for the date " + dateString);
    } else {
      System.out.println("An entry for the date " + dateString + " was found:");
      this.displayCovidLocationStats(covidLocStats);
    }
  }


  /**
   * Shows all Covid statistics registered after the date provided by the user.
   */
  public void findCovidStatsAfterDate() {
    Scanner reader = new Scanner(System.in);

    System.out.println("Please enter the date to search from (YYYY-MM-DD): ");
    String dateString = reader.nextLine();

    LocalDate date = LocalDate.parse(dateString);

    ArrayList<CovidLocationStats> covidLocStatsList =
        this.covidStatsRegister.findCovidStatsAfterDate(date);
    if (covidLocStatsList.isEmpty()) {
      System.out.println("No Covid-19 statistics was found after the date " + dateString);
    } else {
      System.out.println("The following entries after the date " + dateString + " were found:\n");

      System.out.print(TABLE_TITLE);
      System.out.println(TABLE_DIVIDER);

      for (CovidLocationStats covidStat : covidLocStatsList) {
        System.out.format(FORMAT_ROW
            , covidStat.getDate().toString()
            , covidStat.getCountry()
            , covidStat.getNumberOfInfected()
            , covidStat.getNumberOfDeaths());
      }
      System.out.println();
    }
  }

  /**
   * Calculates the number of deaths in a given country provided by the user.
   */
  public void calculateDeathsByCountry() {
    Scanner reader = new Scanner(System.in);
    System.out.println("Please enter which country you would like to look at: ");
    String country = reader.nextLine();

    if (country.trim().isEmpty()) {
      System.out.println("Sorry, you have to provide a country.");
    } else {
      Iterator<CovidLocationStats> it = this.covidStatsRegister.getIterator();
      int sumDeaths = 0;
      boolean noCountryFound = true;  // Used to indicate that no match for country was found
      while (it.hasNext()) {
        CovidLocationStats covidLocStat = it.next();
        if (covidLocStat.getCountry().equalsIgnoreCase(country)) {
          sumDeaths += covidLocStat.getNumberOfDeaths();
          noCountryFound = false;
        }
      }
      if (noCountryFound) {
        System.out.println("There are no entries for the country " + country + " in the register.");
      } else {
        System.out.println("The total number of deaths in "
            + country + " is " + sumDeaths + ".");
      }
    }
  }

  /**
   * Prints the details of a single CovidLocationStats object.
   *
   * @param covidLocationStats the Covid location stats to display
   */
  private void displayCovidLocationStats(CovidLocationStats covidLocationStats) {
    System.out.println("Date: " + covidLocationStats.getDate().toString());
    System.out.println("Country: " + covidLocationStats.getCountry());
    System.out.println("Number of infected: " + covidLocationStats.getNumberOfInfected());
    System.out.println("Number of deaths: " + covidLocationStats.getNumberOfDeaths());
  }

}
